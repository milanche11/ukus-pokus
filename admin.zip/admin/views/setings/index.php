<h1>Setings</h1><hr>
<h3>Demo mod</h3>
<p>Demo mod Vam omogucava da popunite bazu sa 32000 recepata</p>


<form method="post" action="<?php $_SERVER['PHP_SELF']; ?>">
	<button type="submit" class="btn btn-danger btn-sm" name="install" value="install">Install</button>
</form><hr>
<?php




?>