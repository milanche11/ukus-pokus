<?php

// Define DB Params
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "ukuspokus");

// Define URL
define("ROOT_PATH", "/ukus-pokus/admin/");
define("ROOT_URL", "http://localhost/ukus-pokus/admin/");
