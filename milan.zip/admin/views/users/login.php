<?php if(isset($_SESSION['is_logged_in'])) {
  header('Location: '.ROOT_URL.'dashboard');
} ?>

<div class="row justify-content-center">

    

  <div class="panel-body col-5"">
    <h3>User Login</h3>
    <form method="post" action="<?php $_SERVER['PHP_SELF']; ?>">
    	<div class="form-group">
    		<label>Email</label>
    		<input type="text" name="email" class="form-control" />
    	</div>
    	<div class="form-group">
    		<label>Password</label>
    		<input type="password" name="password" class="form-control" />
    	</div>
    	<input class="btn btn-primary" name="submit" type="submit" value="Submit" />
    </form>
  </div>
</div>



  <div class="row justify-content-center">

  </div>