<?php
class DashboardModel extends Model{
	public function Index(){
		return;
	}
}