<?php
class HomeModel extends Model{
	public function Index(){
		return;
	}
}