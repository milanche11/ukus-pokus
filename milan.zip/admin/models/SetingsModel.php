<?php
class SetingsModel extends Model{
	public function Index(){
		return;
	}
}